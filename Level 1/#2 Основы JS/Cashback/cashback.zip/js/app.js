const input = 1000;
const storePercent = 50;
const cashback = input/100 * storePercent;
console.log(cashback);