const partners = [
	{
		id: 'volna',
		url: 'https://salom.alif.tj/partners#/partners/volna',
		logoUrl: 'https://salom.alif.tj/api/salom/v0/images/bh3ah2805vneb2veo2ig.png',
		category: 'Бытовая техника'
	},
	{
		id: 'avrang',
		url: 'https://salom.alif.tj/partners#/partners/avrang',
		logoUrl: 'https://salom.alif.tj/api/salom/v0/images/bh3aj4805vneb2veo2j0.png',
		category: 'Бытовая техника'
	},
	{
		id: 'lcwaikiki',
		url: 'https://salom.alif.tj/partners#/partners/lcwaikiki',
		logoUrl: 'https://salom.alif.tj/api/salom/v0/images/bh5vhg005vn8hjvgidtg.png',
		category: 'Одежда и обувь'
	},
	{
		id: 'lacite',
		url: 'https://salom.alif.tj/partners#/partners/lacite',
		logoUrl: 'https://salom.alif.tj/api/salom/v0/images/bh5aim805vnam9kv2h40.png',
		category: 'Парфюмерия'
	},
];

console.log(partners);